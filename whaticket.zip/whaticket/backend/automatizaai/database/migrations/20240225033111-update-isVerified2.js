'use strict';
module.exports = {
    up: async (queryInterface, Sequelize) => {
        await queryInterface.sequelize.query(`
      UPDATE "Companies" SET "isVerified" = true WHERE "id" = 1;
    `);
    },
    down: async (queryInterface, Sequelize) => {
    },
};
